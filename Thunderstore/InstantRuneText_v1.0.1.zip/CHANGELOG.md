| `Version` | `Update Notes`                |
|-----------|-------------------------------|
| 1.0.1     | - Update for Hildir's Request |
| 1.0.0     | - Initial Release             |