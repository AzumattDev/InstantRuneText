| `Version` | `Update Notes`                                                                           |
|-----------|------------------------------------------------------------------------------------------|
| 1.0.5     | - Update for Valheim 0.220.3                                                             |
| 1.0.4     | - Update for Valheim Bog Witch                                                           |
| 1.0.3     | - Update for Valheim 0.217.46 (just updating to show I cared to check, no code changes.) |
| 1.0.2     | - Update for Valheim 0.217.22 (just updating to show I cared to check, no code changes.) |
| 1.0.1     | - Update for Hildir's Request                                                            |
| 1.0.0     | - Initial Release                                                                        |